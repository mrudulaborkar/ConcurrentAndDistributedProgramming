

import sys
import time
import select



LED_1	=	(0 * 32) + 3		
LED_2	=	(0 * 32) + 23		
LED_3	=	(0 * 32) + 2		
LED_4	=	(0 * 32) + 26		

LED_5	=	(1 * 32) + 17		
LED_6	=	(1 * 32) + 15		
LED_7	=	(0 * 32) + 15		
LED_8	=	(1 * 32) + 14		

LED_9	=	(0 * 32) + 30
LED_10	=	(2 * 32) + 2
LED_11	=	(1 * 32) + 28
LED_12	=	(2 * 32) + 3
LED_13	=	(0 * 32) + 31
LED_14	=	(2 * 32) + 5
LED_15	=	(1 * 32) + 18

SW_1	=	(0 * 32) + 14		
SW_2	=	(0 * 32) + 27		
SW_3	=	(0 * 32) + 22		
SW_4	=	(2 * 32) + 1	



LIFT_DIR_1   =    LED_9
LIFT_DIR_2   =    LED_10
LIFT_DIR_3   =    LED_11
LIFT_DIR_4   =    LED_12
LIFT_DIR_5   =    LED_13
LIFT_DIR_6   =    LED_14
LIFT_DIR_7   =    LED_15



LIFT_POS_0   =    LED_5
LIFT_POS_1   =    LED_6
LIFT_POS_2   =    LED_7
LIFT_POS_3   =    LED_8



LIFT_BUTTON_0   =    SW_1
LIFT_BUTTON_1   =    SW_2
LIFT_BUTTON_2   =    SW_3
LIFT_BUTTON_3   =    SW_4


LIFT_LED_0   =    LED_1
LIFT_LED_1   =    LED_2
LIFT_LED_2   =    LED_3
LIFT_LED_3   =    LED_4



dir_leds = [ 	LIFT_DIR_1,
		LIFT_DIR_2,
		LIFT_DIR_3,
		LIFT_DIR_4,
		LIFT_DIR_5,
		LIFT_DIR_6,
		LIFT_DIR_7
	   ]	


pos_leds = [
		LIFT_POS_0,
		LIFT_POS_1,
		LIFT_POS_2,
		LIFT_POS_3
	   ]


lift_leds = [
		LIFT_LED_0,
		LIFT_LED_1,
		LIFT_LED_2,
		LIFT_LED_3
	   ]


lift_buttons = [
		 LIFT_BUTTON_0,
		 LIFT_BUTTON_1,
		 LIFT_BUTTON_2,
		 LIFT_BUTTON_3
	   ]


NO_OF_FLOORS	  =	4		# No of floors for Lift Simulation Operation
NO_OF_DIR_LEDS	  =	7		# No of LEDs used for the lift direction (on Board)
DEFAULT_LIFT_POS =	0		# The floor no where lift is positioned when program is executed



floor_set = [
		{"fd":-1, "button":LIFT_BUTTON_0, "led":LIFT_LED_0},		# fd, Button and LED for 0th (Ground) Floor
		{"fd":-1, "button":LIFT_BUTTON_1, "led":LIFT_LED_1},		# fd, Button and LED for 1st Floor
		{"fd":-1, "button":LIFT_BUTTON_2, "led":LIFT_LED_2},		# fd, Button and LED for 2nd Floor        
		{"fd":-1, "button":LIFT_BUTTON_3, "led":LIFT_LED_3}		# fd, Button and LED for 3rd Floor

             ]
             

SYSFS_GPIO_DIR = "/sys/class/gpio"


             	

def gpioExport (gpio): 
	try:
   		fo = open(SYSFS_GPIO_DIR + "/export","w")  			
   		fo.write(gpio)
   		fo.close()
   		return
   	except IOError:
                return


def gpioUnexport (gpio):
	try: 
   		fo = open(SYSFS_GPIO_DIR + "/unexport","w")  
   		fo.write(gpio)
   		fo.close()
   		return
   	except IOError:
 		return




def gpioSetDir (gpio, flag):
	try: 
	   	fo = open(SYSFS_GPIO_DIR + "/gpio" + gpio + "/direction" ,"w")  
	   	fo.write(flag)
	   	fo.close()
	   	return
 	except IOError:
                return



def gpioSetVal (gpio, val):
	try: 
		fo = open(SYSFS_GPIO_DIR + "/gpio" + gpio + "/value" ,"w")  
		fo.write(val)
		fo.close()
		return
	except IOError:
                return




def gpioSetEdge (gpio, flag): 
	try:
		fo = open(SYSFS_GPIO_DIR + "/gpio" + gpio + "/edge" ,"w")  
		fo.write(flag)
		fo.close()
   		return
	except IOError:
                return


def liftLEDExit (gpio):
	gpioSetVal(gpio, val="0")
	gpioUnexport(gpio)
	return 



	
def liftLEDInit (gpio):
	gpioExport(gpio)
	gpioSetDir(gpio, flag="out")
 	gpioSetVal(gpio, val="0")
 	return



 	
def liftLEDOn (gpio):
	gpioSetVal(gpio, val="1")
	return 



def liftLEDOff (gpio):
	gpioSetVal(gpio, val="0")
	return 



def liftButtonExit (gpio):
	gpioUnexport(gpio)
	return 
	

def liftButtonInit (gpio):
	gpioExport(gpio)
	gpioSetDir(gpio, flag="in")
 	gpioSetEdge(gpio, flag="falling")
 	return





def liftInitAll():
	for i in range(0, NO_OF_DIR_LEDS):
		liftLEDInit(str(dir_leds[i]))
			
	for i in range(0, NO_OF_FLOORS):
		liftLEDInit(str(pos_leds[i]))
		liftLEDInit(str(lift_leds[i]))
		liftButtonInit(str(lift_buttons[i]))
	return	



def liftExitAll():
	for i in range(0, NO_OF_DIR_LEDS):
		liftLEDExit(str(dir_leds[i]))
			
	for i in range(0, NO_OF_FLOORS):
		liftLEDExit(str(pos_leds[i]))
		liftLEDExit(str(lift_leds[i]))
		liftButtonExit(str(lift_buttons[i]))
	print "\n=== Demonstration END ===\n"
	return	


def liftDefaultPos():
	liftLEDOn(str(pos_leds[DEFAULT_LIFT_POS]))
	return 



def liftDirUp():
	for i in range(0, NO_OF_DIR_LEDS):
		liftLEDOn(str(dir_leds[i]))
		time.sleep(0.5)
	for i in range(0, NO_OF_DIR_LEDS):
		liftLEDOff(str(dir_leds[i]))
	return




def liftDirDown():
	for i in range(NO_OF_DIR_LEDS, 0, -1):
		liftLEDOn(str(dir_leds[i-1]))
		time.sleep(0.5)
	for i in range(0, NO_OF_DIR_LEDS):
		liftLEDOff(str(dir_leds[i]))
	return



def GetButtonVal(): 
	try:		
		fo0 = open(SYSFS_GPIO_DIR + "/gpio" + str(LIFT_BUTTON_0) + "/value" ,"r") # Open and get file descriptor of button file of 0th floor 
		fo0.read(2)								  # Make dummy read() call on it	
		floor_set[0]["fd"] = fo0						  # store fd in 0th element of floor_set array	
		
		fo1 = open(SYSFS_GPIO_DIR + "/gpio" + str(LIFT_BUTTON_1) + "/value" ,"r") # Open and get file descriptor of button file of 1st floor
		fo1.read(2)								  # Make dummy read() call on it   	
		floor_set[1]["fd"] = fo1						  # store fd in 1st element of floor_set array
		
		fo2 = open(SYSFS_GPIO_DIR + "/gpio" + str(LIFT_BUTTON_2) + "/value" ,"r") # Open and get file descriptor of button file of 2nd floor
		fo2.read(2)								  # Make dummy read() call on it	
		floor_set[2]["fd"] = fo2						  # store fd in 2nd element of floor_set array	
		
		fo3 = open(SYSFS_GPIO_DIR + "/gpio" + str(LIFT_BUTTON_3) + "/value" ,"r") # Open and get file descriptor of button file of 3rd floor
		fo3.read(2)								  # Make dummy read() call on it   	
		floor_set[3]["fd"] = fo3						  # store fd in 3rd element of floor_set array
		
		print "\nWaiting for button press ..."
		
		 
		r, w, ex = select.select([], [], [fo0, fo1, fo2, fo3])			
						
								
		for i in range(len(floor_set)):						# Run a loop for all (4) floors				
			if floor_set[i]["fd"] in ex:					# Check current fd is present in ex (ex=list of fds on which data is available)  	
				print "LIFT button is pressed for floor #%d" % i	# Print the floor no indicated by i
				liftLEDOn(str(floor_set[i] ["led"]))			# Glow the corresponding LED for floor indicated by i to show button press event
				time.sleep(1)						# Wait for 1 second
				but = i							# Store value of i in but variable
				fo = floor_set[i]["fd"]					# Get the current fd from array 	
				fo.seek(0, 0);						# Call seek() so that fd will point at begining of the file
				str1 = fo.read(1)					# Make dummy read() call on it 
	
		fo0.close()								# Close fd for 0th floor
		fo1.close()								# Close fd for 1st floor
		fo2.close()								# Close fd for 2nd floor
		fo3.close()								# Close fd for 3rd floor
		return but
	
	except IOError:
                return


try:
	print "\nLift Operation Simulation using Python\n"
	print  "-----------------------------------------------\n" 	
	liftInitAll()							# Initialize all lift Buttons and LEDs	
	liftDefaultPos()						# Set dafault position of the lift (0th floor)

	cur_flr = DEFAULT_LIFT_POS					# Variable for current lift floor (initially 0)
	
	while True:
		new_flr = GetButtonVal()		# Get a new floor value by detecting a floor no to which button user calls the lift
		if new_flr > cur_flr:				# if (new floor > current floor) means lift is called to upper floor	
			tmp = cur_flr						# store current floor no into tmp variable
			print "LIFT going UP to floor #%d" %new_flr		# print destination floor
			while (tmp != new_flr):					# Use tmp value (incremental); till it becomes destination
				liftDirUp()					# Glow direction LEDs in upward direction
				time.sleep(0.01)				# sleep for 10 ms
				liftLEDOff(str(pos_leds[tmp]))			# Turn off position LED at the floor pointed by tmp
				tmp += 1					# Increment tmp value by 1
				liftLEDOn(str(pos_leds[tmp]))			# Turn ON position LED at the floor pointed by tmp. Lift is one floor UP
				time.sleep(0.5)					# Sleep for 0.5 second (500 ms)
		elif new_flr < cur_flr:				# if (new floor < current floor) means lift is called to lower floor
			tmp = cur_flr						# store current floor no into tmp variable
			print "LIFT going DOWN to floor #%d" %new_flr		# print destination floor
			while (tmp != new_flr):					# Use tmp value (decremental); till it becomes destination
				liftDirDown()					# Glow direction LEDs in downward direction
				time.sleep(0.01)				# Sleep for 10 ms
				liftLEDOff(str(pos_leds[tmp]))			# Turn off position LED at the floor pointed by tmp
				tmp -= 1					# Decrement tmp value by 1
				liftLEDOn(str(pos_leds[tmp]))			# Turn ON position LED at the floor pointed by tmp. Lift is one floor DOWN
				time.sleep(0.5)					# sleep for 0.5 second (500 ms)	
		
		cur_flr = new_flr			# Once lift reaches the destination; current floor points to destination floor no
		liftLEDOff(str(lift_leds[new_flr]))	# Turn OFF button press indication LED of the destinaton floor
		time.sleep(1)				# Sleep for 1 second
		 
	liftExitAll()					# Clean up all GPIOs	
	exit()						# Exit from Program
except KeyboardInterrupt:				# CTRL-C Exception Handler to cleanup and exit safely from program
	liftExitAll()	
	print "Program Exit due to CTRL-C"
	exit()
    	sys.exit(0)
