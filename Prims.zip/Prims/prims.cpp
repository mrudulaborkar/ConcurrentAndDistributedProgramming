#include<iostream>
#include<stdlib.h>
#include<omp.h>

#define true 1
#define false 0
using namespace std;
int nodes,cost[10][10],edges,k,i,j,visited[10],vis=1,sum,x,y;
double start_time;

int main()
{
	int m=999,c;
	cout <<"Enter no of nodes";
	cin >> nodes;
	cout <<"Enter no of edges";
	cin >> edges;
	for(k=1;k<=edges;k++)
	{
		cout <<"EDGE FROM \tTo \t Cost\n";
		cin >>i>>j>>c;
		cost[i][j]=c;
		cost[j][i]=c;
		cout<<"Edge Inserted\n";
	}
	start_time=omp_get_wtime();
	for(i=1;i<=nodes;i++)
	{
		for(j=1;j<=nodes;j++)
		{
			if(cost[i][j]==0)
				cost[i][j]=999;
			
		}
	}
	visited[1]=true;
	cout<<"\nThe Minimum route is as follows:\n";
	while(vis<nodes)
	{
		#pragma omp parallel for
		for(i=1;i<=nodes;i++)
		{
			if(visited[i]==true)
			{
				for(j=1;j<=nodes;j++)
				{
					if((cost[i][j]<=m) && (visited[j]==false))
					{
					#pragma omp critical
						{
						m=cost[i][j];
						x=i;
						y=j;
						}
					}

				}
			}
		}
		vis=vis+1;
		sum=sum+m;
		cout<<x<<"==>"<<y<<"\tCost:"<<cost[x][y]<<endl;		
		cost[x][y]=999;
		cost[y][x]=999;
		//cout<<x<<"==>"<<y<<endl;
		visited[y]=true;
		m=999;
	}
	cout<<"\nThe least cost is:"<<sum<<endl;
	cout<<"The time taken for execution:"<<(omp_get_wtime()-start_time)<<endl;
	return 0;
}



output:


[root@localhost ~]$ g++ -fopenmp prims.cpp
[root@localhost ~]$ ./a.out
Enter no of nodes4
Enter no of edges5
EDGE FROM 	To 	 Cost
1 2 5 
Edge Inserted
EDGE FROM 	To 	 Cost
1 3 10
Edge Inserted
EDGE FROM 	To 	 Cost
2 3 4 
Edge Inserted
EDGE FROM 	To 	 Cost
2 4 11
Edge Inserted
EDGE FROM 	To 	 Cost
3 4 5
Edge Inserted

The Minimum route is as follows:
1==>2	Cost:5
2==>3	Cost:4
3==>4	Cost:5

The least cost is:14
The time taken for execution:0.0654986
